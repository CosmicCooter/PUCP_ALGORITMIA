/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funciones.cpp
 * Author: oscar
 * 
 * Created on December 20, 2024, 11:44 PM
 */

#include "funciones.h"

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

/*
 * 
 */
// n son la cantidad de símbolos dibujados, en este caso, la cantidad máxima es 8 
// i son los espacios vacíos 
void patron(int n, int i) {
    if (n == 1) {   
        //caso base, cuando n es igual a 1, se imprimen tantos espacios en blanco como el número de i
        for (int o = 0; o < i; o++) cout << ' ';
        //posteriormente se imprime un simbolo, como requiere la imagen
        cout << '+' << endl;     
        //se retorna para terminar la recursión
        return;
    } else {
        //se hace la llamada recursiva para realizar el dibujo inicial
        //la llamada es con n / 2 pues se dibuja la mitad cada vez, 8, 4, 2, ...
        patron(n / 2, i);
        //se realiza la función principal que dibuja los espacios en 
        //blanco requeridos y posteriormente los símbolos
        for (int o = 0; o < i; o++) cout << ' ';
        for (int o = 0; o < n; o++) cout << '+';
        cout << endl;
        //se finaliza la ejecución de la recursión al llamar la función otra vez, 
        //en este caso aumentando la impresión de los espacios en blanco según 
        //los símbolos impresos anteriormente, si se imprimen 8, se hace una impresión con 4 espacios en blanco
        patron(n / 2, i + n/2);
    }
}

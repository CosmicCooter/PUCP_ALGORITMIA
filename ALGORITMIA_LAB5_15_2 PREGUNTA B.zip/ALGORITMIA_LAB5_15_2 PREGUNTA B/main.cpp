/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: oscarL
 *
 * Created on August 30, 2024, 5:23 PM
 */

#include <cstdlib>
using namespace std;
#include "funciones.h"

/*
 * 
 */

int main(int argc, char** argv) {
    patron(8, 0);
    return 0;
}

/* RESULTADO ESPERADO
+
++
 +
++++
  +
  ++
   +
++++++++
    +
    ++
     +
    ++++
      +
      ++
       +

*/
